const express = require('express')
const app = express()
const port = 3001
// publico la carpeta de cliente
app.use(express.static("cliente/dist"));

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})