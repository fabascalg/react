import React, {Component} from "react";
import ReactDOM from "react-dom";
import {ListaAlumnnos} from "./listaalumnos.js"
import {FormularioAlumno} from "./formularioalumno.js";

window.onload=function() {

    let tabla = <div><ListaAlumnnos /><FormularioAlumno /></div>
    ReactDOM.render(tabla, document.getElementById("zona"));

}