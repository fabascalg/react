import React ,{Component} from "react"
import axios from "axios"
import {FilaAlumno} from "./filaalumno.js";

export class ListaAlumnos extends React.Component {

    constructor(props) {
      super(props);
      this.state = {
        alumnos: []
      }
      this.borrar = this.borrar.bind(this);
      this.detalle = this.detalle.bind(this);
    }
    componentDidMount() {

      

    }
    borrar(alumno) {
     
      this.props.onBorrar(alumno);
    }

    detalle(alumno) {
     
      this.props.onDetalle(alumno);
    }
    render() {

      return <table>
        <tbody>
          {this.props.alumnos.map((alumno) => <FilaAlumno key={alumno.nombre} onBorrar={this.borrar} alumno={alumno} onDetalle={this.detalle} />)}
        </tbody>
      </table>

    }
  }