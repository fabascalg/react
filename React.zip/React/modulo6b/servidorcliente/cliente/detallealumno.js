
import React ,{Component} from "react"

export class DetalleAlumno extends React.Component {

    constructor(props) {
      super(props);
     
    }

   

    render() {
      return <div> El detalle es:
        <p>{this.props.alumno.nombre}</p>
        <p>{this.props.alumno.nota}</p>
      </div>
    }

  }