
import React ,{Component} from "react"

export class FilaAlumno extends React.Component {

    constructor(props) {
      super(props);
      this.borrar = this.borrar.bind(this);
      this.detalle = this.detalle.bind(this);
    }

    borrar() {


      console.log("desde la fila" + this.props.alumno)

      this.props.onBorrar(this.props.alumno);

    }
    detalle() {

      this.props.onDetalle(this.props.alumno);

    }


    render() {
      return <tr>
        <td>{this.props.alumno.nombre}</td>
        <td>{this.props.alumno.nota}</td>
        <td><input type="button" value="borrar" onClick={this.borrar} /></td>
        <td><input type="button" value="detalle" onClick={this.detalle} /></td>
      </tr>
    }

  }