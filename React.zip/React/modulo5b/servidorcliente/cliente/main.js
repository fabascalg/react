import React, {Component} from "react";
import ReactDOM from "react-dom";
import {ListaAlumnnos} from "./listaalumnos.js"
import {FormularioAlumno} from "./formularioalumno.js";
import {Contenedor} from "./contenedor.js";

window.onload=function() {

    let contenedor = <Contenedor/>
    ReactDOM.render(contenedor, document.getElementById("zona"));

}