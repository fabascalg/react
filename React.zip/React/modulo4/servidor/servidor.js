const express = require('express')
const app = express()
const bodyParser=require("body-parser");
const port = 3000
// activamos crosss origin request sharing
var cors= require("cors");

app.use(cors());
// la  capacidad del servidor de leer objets en json 
// que vengan de un cliente
app.use(bodyParser.json());
let alumnos=[];
alumnos.push({"nombre":"pepe",nota:5},{"nombre":"ana",nota:7});

// pepe
app.delete("/alumnos/:nombre",(req,res)=> {

  //objeto que tiene de nombre pepe
  let seleccionado= alumnos.filter(function(elemento) {

    return elemento.nombre==req.params.nombre;

  })[0];

  let indice= alumnos.indexOf(seleccionado);
  alumnos.splice(indice,1);
  res.status(204).send();

})

app.post("/alumnos",(req,res)=> {
  // peticion post
  alumnos.push(req.body);
  res.status(201).send();
})

app.get("/alumnos",(req,res)=> {

    res.send(alumnos);
})

app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})